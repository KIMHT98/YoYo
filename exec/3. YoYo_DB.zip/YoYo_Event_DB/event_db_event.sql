-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: j11a308.p.ssafy.io    Database: event_db
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `event`
--

DROP TABLE IF EXISTS `event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event` (
  `event_id` bigint NOT NULL AUTO_INCREMENT,
  `end_at` datetime(6) DEFAULT NULL,
  `event_type` enum('FUNERAL','OTHERS','WEDDING') DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `member_id` bigint DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `start_at` datetime(6) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`event_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event`
--

LOCK TABLES `event` WRITE;
/*!40000 ALTER TABLE `event` DISABLE KEYS */;
INSERT INTO `event` VALUES (1,'2024-10-11 00:00:00.000000','WEDDING','경기도 남양주시 금곡',6,'김현태','2024-10-10 00:00:00.000000','내 결혼식'),(2,'2024-11-09 12:00:00.000000','WEDDING','서울시 강남구 역삼동',1,'최광림','2024-11-09 11:00:00.000000','축복의 결혼식'),(3,'2024-11-16 15:00:38.051000','OTHERS','제주특별자치도',2,'서진경','2024-11-16 15:00:38.051000','즐거운 돌잔치'),(4,'2024-10-26 15:00:38.051000','WEDDING','서울시 사당동',3,'김찬규','2024-10-26 15:00:38.051000','영광스러운 결혼식'),(5,'2024-10-19 15:00:38.051000','WEDDING','서울시 영등포구',4,'장혜원','2024-10-19 15:00:38.051000','사랑의 결혼식'),(6,'2024-11-03 15:00:38.051000','OTHERS','서울시 관악구',5,'이찬진','2024-11-03 15:00:38.051000','까꿍 돌잔치'),(7,'2024-11-10 15:00:38.051000','OTHERS','서울시 왕십리',6,'김현태','2024-11-10 15:00:38.051000','귀여운 돌잔치');
/*!40000 ALTER TABLE `event` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-11  8:48:20
