-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: j11a308.p.ssafy.io    Database: transaction_db
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `transaction`
--

DROP TABLE IF EXISTS `transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transaction` (
  `is_register` bit(1) DEFAULT NULL,
  `amount` bigint NOT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `event_id` bigint DEFAULT NULL,
  `receiver_id` bigint DEFAULT NULL,
  `sender_id` bigint DEFAULT NULL,
  `transaction_id` bigint NOT NULL AUTO_INCREMENT,
  `updated_at` datetime(6) DEFAULT NULL,
  `dtype` varchar(31) NOT NULL,
  `event_name` varchar(255) DEFAULT NULL,
  `memo` varchar(255) DEFAULT NULL,
  `receiver_name` varchar(255) DEFAULT NULL,
  `sender_name` varchar(255) DEFAULT NULL,
  `relation_type` enum('COMPANY','ETC','FAMILY','FRIEND','NONE') DEFAULT NULL,
  `transaction_type` enum('AUTO','RECEIVE','SEND') DEFAULT NULL,
  PRIMARY KEY (`transaction_id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction`
--

LOCK TABLES `transaction` WRITE;
/*!40000 ALTER TABLE `transaction` DISABLE KEYS */;
INSERT INTO `transaction` VALUES (_binary '',100000,'2024-10-10 14:48:10.899528',2,1,2,1,'2024-10-10 14:54:00.419529','Transaction','축복의 결혼식',NULL,'최광림','서진경','FRIEND','AUTO'),(_binary '',100000,'2024-10-10 14:48:52.170720',2,1,3,2,'2024-10-10 14:54:22.067719','Transaction','축복의 결혼식',NULL,'최광림','김찬규','FRIEND','AUTO'),(_binary '',100000,'2024-10-10 14:48:58.830804',2,1,5,3,'2024-10-10 14:54:30.715710','Transaction','축복의 결혼식',NULL,'최광림','이찬진','FRIEND','AUTO'),(_binary '',200000,'2024-10-10 14:49:09.613749',2,1,7,4,'2024-10-10 14:55:19.766616','Transaction','축복의 결혼식',NULL,'최광림','김윤아','FAMILY','AUTO'),(_binary '',50000,'2024-10-10 14:49:14.708946',2,1,8,5,'2024-10-10 14:55:26.072007','Transaction','축복의 결혼식',NULL,'최광림','이민준','FAMILY','AUTO'),(_binary '',70000,'2024-10-10 14:49:20.830194',2,1,9,6,'2024-10-10 14:55:43.141771','Transaction','축복의 결혼식',NULL,'최광림','박서연','FRIEND','AUTO'),(_binary '',100000,'2024-10-10 14:49:25.982507',2,1,10,7,'2024-10-10 14:55:46.244168','Transaction','축복의 결혼식',NULL,'최광림','최지후','FRIEND','AUTO'),(_binary '',150000,'2024-10-10 14:49:30.100264',2,1,11,8,'2024-10-10 14:55:55.847289','Transaction','축복의 결혼식',NULL,'최광림','정하준','FRIEND','AUTO'),(_binary '',50000,'2024-10-10 14:49:36.832346',2,1,12,9,'2024-10-10 14:56:01.832742','Transaction','축복의 결혼식',NULL,'최광림','강예린','FRIEND','AUTO'),(_binary '',100000,'2024-10-10 14:49:42.744476',2,1,13,10,'2024-10-10 14:56:12.257051','Transaction','축복의 결혼식',NULL,'최광림','조도현','FRIEND','AUTO'),(_binary '',100000,'2024-10-10 14:49:49.103893',2,1,14,11,'2024-10-10 14:56:15.440831','Transaction','축복의 결혼식',NULL,'최광림','임수빈','FRIEND','AUTO'),(_binary '',100000,'2024-10-10 14:49:50.836584',2,1,15,12,'2024-10-10 14:56:27.526796','Transaction','축복의 결혼식',NULL,'최광림','한지민','FRIEND','AUTO'),(_binary '',100000,'2024-10-10 14:49:52.458255',2,1,16,13,'2024-10-10 14:56:30.732981','Transaction','축복의 결혼식',NULL,'최광림','오유진','FRIEND','AUTO'),(_binary '',100000,'2024-10-10 14:49:54.283039',2,1,17,14,'2024-10-10 14:56:33.690030','Transaction','축복의 결혼식',NULL,'최광림','이서현','FRIEND','AUTO'),(_binary '',50000,'2024-10-10 14:49:58.818185',2,1,18,15,'2024-10-10 14:56:44.319979','Transaction','축복의 결혼식',NULL,'최광림','김지우','FRIEND','AUTO'),(_binary '',50000,'2024-10-10 14:50:01.009911',2,1,19,16,'2024-10-10 14:56:46.969354','Transaction','축복의 결혼식',NULL,'최광림','배수진','FRIEND','AUTO'),(_binary '',50000,'2024-10-10 14:50:04.044166',2,1,20,17,'2024-10-10 14:56:55.728465','Transaction','축복의 결혼식',NULL,'최광림','홍길동','FRIEND','AUTO'),(_binary '',100000,'2024-10-10 14:50:10.418807',2,1,21,18,'2024-10-10 14:56:57.366343','Transaction','축복의 결혼식',NULL,'최광림','최민수','FRIEND','AUTO'),(_binary '',70000,'2024-10-10 14:50:16.939396',2,1,22,19,'2024-10-10 14:56:59.436103','Transaction','축복의 결혼식',NULL,'최광림','안재현','FRIEND','AUTO'),(_binary '',70000,'2024-10-10 14:50:19.761840',2,1,23,20,'2024-10-10 14:57:16.252016','Transaction','축복의 결혼식',NULL,'최광림','윤아름','FAMILY','AUTO'),(_binary '',70000,'2024-10-10 14:50:22.727266',2,1,24,21,'2024-10-10 14:57:20.212036','Transaction','축복의 결혼식',NULL,'최광림','서지수','FAMILY','AUTO'),(_binary '',70000,'2024-10-10 14:50:24.723105',2,1,25,22,'2024-10-10 14:57:34.676479','Transaction','축복의 결혼식',NULL,'최광림','차정우','COMPANY','AUTO'),(_binary '',150000,'2024-10-10 14:50:30.009800',2,1,26,23,'2024-10-10 14:57:39.014723','Transaction','축복의 결혼식',NULL,'최광림','백승호','COMPANY','AUTO'),(_binary '',150000,'2024-10-10 14:50:34.478201',2,1,27,24,'2024-10-10 14:57:44.391541','Transaction','축복의 결혼식',NULL,'최광림','손지혜','COMPANY','AUTO'),(_binary '',150000,'2024-10-10 14:50:36.851422',2,1,28,25,'2024-10-10 14:57:53.051845','Transaction','축복의 결혼식',NULL,'최광림','강민재','COMPANY','AUTO'),(_binary '',150000,'2024-10-10 14:50:39.498342',2,1,29,26,'2024-10-10 14:58:09.719322','Transaction','축복의 결혼식',NULL,'최광림','이수정','ETC','AUTO'),(_binary '',150000,'2024-10-10 14:50:44.572359',2,1,30,27,'2024-10-10 14:58:12.831168','Transaction','축복의 결혼식',NULL,'최광림','김태희','ETC','AUTO'),(_binary '',100000,'2024-10-10 14:50:50.435234',2,1,31,28,'2024-10-10 14:58:26.895656','Transaction','축복의 결혼식',NULL,'최광림','박준형','COMPANY','AUTO'),(_binary '',100000,'2024-10-10 14:50:52.627548',2,1,32,29,'2024-10-10 14:58:43.038907','Transaction','축복의 결혼식',NULL,'최광림','정민수','FAMILY','AUTO'),(_binary '',100000,'2024-10-10 14:50:54.651775',2,1,33,30,'2024-10-10 14:58:49.568723','Transaction','축복의 결혼식',NULL,'최광림','오영수','FAMILY','AUTO'),(_binary '',100000,'2024-10-10 14:50:56.558709',2,1,34,31,'2024-10-10 14:58:57.144290','Transaction','축복의 결혼식',NULL,'최광림','한보라','FAMILY','AUTO'),(_binary '',100000,'2024-10-10 14:50:59.003900',2,1,35,32,'2024-10-10 14:59:05.457003','Transaction','축복의 결혼식',NULL,'최광림','조현주','FAMILY','AUTO'),(_binary '\0',100000,'2024-10-10 15:14:55.887161',2,1,37,33,'2024-10-10 15:14:55.887161','Transaction','축복의 결혼식','행복하게 잘 살아~','최광림','김슬기','NONE','RECEIVE'),(_binary '',150000,'2024-10-10 15:18:30.193481',2,1,4,34,'2024-10-10 15:18:30.193481','Transaction','축복의 결혼식',NULL,'최광림','장혜원','NONE','AUTO'),(_binary '',150000,'2024-10-10 15:18:33.382651',2,1,6,35,'2024-10-10 15:18:33.382651','Transaction','축복의 결혼식',NULL,'최광림','김현태','NONE','AUTO');
/*!40000 ALTER TABLE `transaction` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-11  8:48:02
