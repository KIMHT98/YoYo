-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: j11a308.p.ssafy.io    Database: member_db
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `base_member`
--

DROP TABLE IF EXISTS `base_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `base_member` (
  `member_id` bigint NOT NULL AUTO_INCREMENT,
  `dtype` varchar(31) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `base_member`
--

LOCK TABLES `base_member` WRITE;
/*!40000 ALTER TABLE `base_member` DISABLE KEYS */;
INSERT INTO `base_member` VALUES (1,'Member','최광림'),(2,'Member','서진경'),(3,'Member','김찬규'),(4,'Member','장혜원'),(5,'Member','이찬진'),(6,'Member','김현태'),(7,'Member','김윤아'),(8,'Member','이민준'),(9,'Member','박서연'),(10,'Member','최지후'),(11,'Member','정하준'),(12,'Member','강예린'),(13,'Member','조도현'),(14,'Member','임수빈'),(15,'Member','한지민'),(16,'Member','오유진'),(17,'Member','이서현'),(18,'Member','김지우'),(19,'Member','배수진'),(20,'Member','홍길동'),(21,'Member','최민수'),(22,'Member','안재현'),(23,'Member','윤아름'),(24,'Member','서지수'),(25,'Member','차정우'),(26,'Member','백승호'),(27,'Member','손지혜'),(28,'Member','강민재'),(29,'Member','이수정'),(30,'Member','김태희'),(31,'Member','박준형'),(32,'Member','정민수'),(33,'Member','오영수'),(34,'Member','한보라'),(35,'Member','조현주'),(36,'Member','김테스트'),(37,'NoMember','김슬기'),(38,'NoMember','이철현'),(39,'NoMember','김철현');
/*!40000 ALTER TABLE `base_member` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-11  8:47:36
