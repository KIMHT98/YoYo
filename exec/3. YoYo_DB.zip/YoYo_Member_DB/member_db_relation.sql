-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: j11a308.p.ssafy.io    Database: member_db
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `relation`
--

DROP TABLE IF EXISTS `relation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `relation` (
  `is_member` bit(1) NOT NULL,
  `member_id` bigint DEFAULT NULL,
  `opposite_id` bigint DEFAULT NULL,
  `relation_id` bigint NOT NULL AUTO_INCREMENT,
  `total_received_amount` bigint NOT NULL,
  `total_sent_amount` bigint NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `opposite_name` varchar(255) DEFAULT NULL,
  `relation_type` enum('COMPANY','ETC','FAMILY','FRIEND','NONE') DEFAULT NULL,
  PRIMARY KEY (`relation_id`),
  KEY `FKp24mb4xg52q79wh8744ca90a3` (`member_id`),
  CONSTRAINT `FKp24mb4xg52q79wh8744ca90a3` FOREIGN KEY (`member_id`) REFERENCES `member` (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `relation`
--

LOCK TABLES `relation` WRITE;
/*!40000 ALTER TABLE `relation` DISABLE KEYS */;
INSERT INTO `relation` VALUES (_binary '',2,1,1,0,100000,'','최광림','NONE'),(_binary '',1,2,2,100000,0,'싸피 친구','서진경','FRIEND'),(_binary '',3,1,3,0,100000,'','최광림','NONE'),(_binary '',1,3,4,100000,0,'싸피 친구','김찬규','FRIEND'),(_binary '',5,1,5,0,100000,'','최광림','NONE'),(_binary '',1,5,6,100000,0,'싸피 친구','이찬진','FRIEND'),(_binary '',7,1,7,0,200000,'','최광림','NONE'),(_binary '',1,7,8,200000,0,'고모','김윤아','FAMILY'),(_binary '',8,1,9,0,50000,'','최광림','NONE'),(_binary '',1,8,10,50000,0,'고모부','이민준','FAMILY'),(_binary '',9,1,11,0,70000,'','최광림','NONE'),(_binary '',1,9,12,70000,0,'고등학교 동창','박서연','FRIEND'),(_binary '',10,1,13,0,100000,'','최광림','NONE'),(_binary '',1,10,14,100000,0,'고등학교 동창','최지후','FRIEND'),(_binary '',11,1,15,0,150000,'','최광림','NONE'),(_binary '',1,11,16,150000,0,'대학교 동기','정하준','FRIEND'),(_binary '',12,1,17,0,50000,'','최광림','NONE'),(_binary '',1,12,18,50000,0,'대학교 동기','강예린','FRIEND'),(_binary '',13,1,19,0,100000,'','최광림','NONE'),(_binary '',1,13,20,100000,0,'중학교 친구','조도현','FRIEND'),(_binary '',14,1,21,0,100000,'','최광림','NONE'),(_binary '',1,14,22,100000,0,'중학교 친구','임수빈','FRIEND'),(_binary '',15,1,23,0,100000,'','최광림','NONE'),(_binary '',1,15,24,100000,0,'대학교 동기','한지민','FRIEND'),(_binary '',16,1,25,0,100000,'','최광림','NONE'),(_binary '',1,16,26,100000,0,'대학교 동기','오유진','FRIEND'),(_binary '',17,1,27,0,100000,'','최광림','NONE'),(_binary '',1,17,28,100000,0,'대학교 동기','이서현','FRIEND'),(_binary '',18,1,29,0,50000,'','최광림','NONE'),(_binary '',1,18,30,50000,0,'고등학교 친구','김지우','FRIEND'),(_binary '',19,1,31,0,50000,'','최광림','NONE'),(_binary '',1,19,32,50000,0,'고등학교 친구','배수진','FRIEND'),(_binary '',20,1,33,0,50000,'','최광림','NONE'),(_binary '',1,20,34,50000,0,'싸피 친구','홍길동','FRIEND'),(_binary '',21,1,35,0,100000,'','최광림','NONE'),(_binary '',1,21,36,100000,0,'싸피 친구','최민수','FRIEND'),(_binary '',22,1,37,0,70000,'','최광림','NONE'),(_binary '',1,22,38,70000,0,'싸피 친구','안재현','FRIEND'),(_binary '',23,1,39,0,70000,'','최광림','NONE'),(_binary '',1,23,40,70000,0,'사촌 동생','윤아름','FAMILY'),(_binary '',24,1,41,0,70000,'','최광림','NONE'),(_binary '',1,24,42,70000,0,'사촌 동생','서지수','FAMILY'),(_binary '',25,1,43,0,70000,'','최광림','NONE'),(_binary '',1,25,44,70000,0,'회사 동기','차정우','COMPANY'),(_binary '',26,1,45,0,150000,'','최광림','NONE'),(_binary '',1,26,46,150000,0,'회사 동기','백승호','COMPANY'),(_binary '',27,1,47,0,150000,'','최광림','NONE'),(_binary '',1,27,48,150000,0,'회사 동기','손지혜','COMPANY'),(_binary '',28,1,49,0,150000,'','최광림','NONE'),(_binary '',1,28,50,150000,0,'회사 팀장님','강민재','COMPANY'),(_binary '',29,1,51,0,150000,'','최광림','NONE'),(_binary '',1,29,52,150000,0,'동아리','이수정','ETC'),(_binary '',30,1,53,0,150000,'','최광림','NONE'),(_binary '',1,30,54,150000,0,'동아리','김태희','ETC'),(_binary '',31,1,55,0,100000,'','최광림','NONE'),(_binary '',1,31,56,100000,0,'회사 과장님','박준형','COMPANY'),(_binary '',32,1,57,0,100000,'','최광림','NONE'),(_binary '',1,32,58,100000,0,'외숙부','정민수','FAMILY'),(_binary '',33,1,59,0,100000,'','최광림','NONE'),(_binary '',1,33,60,100000,0,'이모할머니','오영수','FAMILY'),(_binary '',34,1,61,0,100000,'','최광림','NONE'),(_binary '',1,34,62,100000,0,'고종사촌','한보라','FAMILY'),(_binary '',35,1,63,0,100000,'','최광림','NONE'),(_binary '',1,35,64,100000,0,'작은아버지','조현주','FAMILY'),(_binary '',4,1,65,0,150000,'','최광림','NONE'),(_binary '',1,4,66,150000,0,'싸피 친구','장혜원','FRIEND'),(_binary '',6,1,67,0,150000,'','최광림','NONE'),(_binary '',1,6,68,150000,0,'싸피 친구','김현태','FRIEND');
/*!40000 ALTER TABLE `relation` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-11  8:47:37
