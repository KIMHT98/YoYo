-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: j11a308.p.ssafy.io    Database: notification_db
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `notification`
--

DROP TABLE IF EXISTS `notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification` (
  `is_register` bit(1) DEFAULT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `event_id` bigint DEFAULT NULL,
  `notification_id` bigint NOT NULL AUTO_INCREMENT,
  `receiver_id` bigint DEFAULT NULL,
  `sender_id` bigint DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `type` enum('EVENT','PAY') DEFAULT NULL,
  PRIMARY KEY (`notification_id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification`
--

LOCK TABLES `notification` WRITE;
/*!40000 ALTER TABLE `notification` DISABLE KEYS */;
INSERT INTO `notification` VALUES (_binary '\0','2024-10-10 14:48:10.840257',2,1,1,2,'서진경','축복의 결혼식','PAY'),(_binary '\0','2024-10-10 14:48:52.167286',2,2,1,3,'김찬규','축복의 결혼식','PAY'),(_binary '\0','2024-10-10 14:48:58.819688',2,3,1,5,'이찬진','축복의 결혼식','PAY'),(_binary '\0','2024-10-10 14:49:09.610406',2,4,1,7,'김윤아','축복의 결혼식','PAY'),(_binary '\0','2024-10-10 14:49:14.695108',2,5,1,8,'이민준','축복의 결혼식','PAY'),(_binary '\0','2024-10-10 14:49:20.856276',2,6,1,9,'박서연','축복의 결혼식','PAY'),(_binary '\0','2024-10-10 14:49:25.976978',2,7,1,10,'최지후','축복의 결혼식','PAY'),(_binary '\0','2024-10-10 14:49:30.097656',2,8,1,11,'정하준','축복의 결혼식','PAY'),(_binary '\0','2024-10-10 14:49:36.825897',2,9,1,12,'강예린','축복의 결혼식','PAY'),(_binary '\0','2024-10-10 14:49:42.722635',2,10,1,13,'조도현','축복의 결혼식','PAY'),(_binary '\0','2024-10-10 14:49:49.100529',2,11,1,14,'임수빈','축복의 결혼식','PAY'),(_binary '\0','2024-10-10 14:49:50.839416',2,12,1,15,'한지민','축복의 결혼식','PAY'),(_binary '\0','2024-10-10 14:49:52.452649',2,13,1,16,'오유진','축복의 결혼식','PAY'),(_binary '\0','2024-10-10 14:49:54.283571',2,14,1,17,'이서현','축복의 결혼식','PAY'),(_binary '\0','2024-10-10 14:49:58.812635',2,15,1,18,'김지우','축복의 결혼식','PAY'),(_binary '\0','2024-10-10 14:50:00.995764',2,16,1,19,'배수진','축복의 결혼식','PAY'),(_binary '\0','2024-10-10 14:50:04.040634',2,17,1,20,'홍길동','축복의 결혼식','PAY'),(_binary '\0','2024-10-10 14:50:10.417915',2,18,1,21,'최민수','축복의 결혼식','PAY'),(_binary '\0','2024-10-10 14:50:16.934719',2,19,1,22,'안재현','축복의 결혼식','PAY'),(_binary '\0','2024-10-10 14:50:19.758658',2,20,1,23,'윤아름','축복의 결혼식','PAY'),(_binary '\0','2024-10-10 14:50:22.725812',2,21,1,24,'서지수','축복의 결혼식','PAY'),(_binary '\0','2024-10-10 14:50:24.719053',2,22,1,25,'차정우','축복의 결혼식','PAY'),(_binary '\0','2024-10-10 14:50:30.009746',2,23,1,26,'백승호','축복의 결혼식','PAY'),(_binary '\0','2024-10-10 14:50:34.475537',2,24,1,27,'손지혜','축복의 결혼식','PAY'),(_binary '\0','2024-10-10 14:50:36.848232',2,25,1,28,'강민재','축복의 결혼식','PAY'),(_binary '\0','2024-10-10 14:50:39.492522',2,26,1,29,'이수정','축복의 결혼식','PAY'),(_binary '\0','2024-10-10 14:50:44.571420',2,27,1,30,'김태희','축복의 결혼식','PAY'),(_binary '\0','2024-10-10 14:50:50.432575',2,28,1,31,'박준형','축복의 결혼식','PAY'),(_binary '\0','2024-10-10 14:50:52.618818',2,29,1,32,'정민수','축복의 결혼식','PAY'),(_binary '\0','2024-10-10 14:50:54.645830',2,30,1,33,'오영수','축복의 결혼식','PAY'),(_binary '\0','2024-10-10 14:50:56.554002',2,31,1,34,'한보라','축복의 결혼식','PAY'),(_binary '\0','2024-10-10 14:50:58.998959',2,32,1,35,'조현주','축복의 결혼식','PAY'),(_binary '\0','2024-10-10 15:01:43.182567',3,33,1,2,'서진경','즐거운 돌잔치','EVENT'),(_binary '\0','2024-10-10 15:02:16.962990',4,34,1,3,'김찬규','영광스러운 결혼식','EVENT'),(_binary '\0','2024-10-10 15:04:09.032629',6,35,1,5,'이찬진','까꿍 돌잔치','EVENT'),(_binary '\0','2024-10-10 15:04:09.032629',5,36,1,4,'장혜원','사랑의 결혼식','EVENT'),(_binary '\0','2024-10-10 15:04:09.032629',7,37,1,6,'김현태','귀여운 돌잔치','EVENT'),(_binary '\0','2024-10-10 15:18:30.194458',2,38,1,4,'장혜원','축복의 결혼식','PAY'),(_binary '\0','2024-10-10 15:18:33.378713',2,39,1,6,'김현태','축복의 결혼식','PAY');
/*!40000 ALTER TABLE `notification` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-11  8:48:11
